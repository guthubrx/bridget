const assert = require("node:assert/strict");
const { DatabaseSync } = require("node:sqlite");
const filename = process.argv[2];
assert.ok(filename, "Private SQLite path required");
assert.ok(process.versions.electron, "This smoke must run under the staged Electron binary");
let database = new DatabaseSync(filename);
database.exec("CREATE TABLE smoke148 (value TEXT NOT NULL)");
database.prepare("INSERT INTO smoke148 (value) VALUES (?)").run("isolated148");
assert.equal(database.prepare("SELECT count(*) AS n FROM smoke148").get().n, 1);
database.close();
database = new DatabaseSync(filename, { readOnly: true });
assert.equal(database.prepare("SELECT value FROM smoke148").get().value, "isolated148");
const quickCheck = database.prepare("PRAGMA quick_check").get().quick_check;
assert.equal(quickCheck, "ok");
const sqliteVersion = database.prepare("SELECT sqlite_version() AS version").get().version;
database.close();
console.log(JSON.stringify({
  electron: process.versions.electron,
  node: process.versions.node,
  modules: process.versions.modules,
  sqliteVersion,
  durableRowRead: true,
  quickCheck,
  guiStarted: false,
  serverStarted: false,
  modelCalled: false,
}));
