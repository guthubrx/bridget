# Préparation des outils de livraison149

Préparation seule. Aucun outil copié exécuté, aucun build, installation, signature, test, Git ou changement de production.

- Dossier privé0700 : /Users/moi/.cache/bridget-delivery149-tools
- Copies : /Users/moi/.cache/bridget-delivery149-tools/build-final.sh ; /Users/moi/.cache/bridget-delivery149-tools/sign-stage.py ; /Users/moi/.cache/bridget-delivery149-tools/verify-final.mjs ; /Users/moi/.cache/bridget-delivery149-tools/sqlite-smoke.cjs
- Provenance SHA256 des originaux et des copies : /Users/moi/.cache/bridget-delivery149-tools/provenance.json
- Diff exact : /Users/moi/.cache/bridget-delivery149-tools/parameterization.diff

## Utilisation T3 future, sous contrôle du principal

`build-final.sh` et `sign-stage.py` prennent argv1 : un packageRoot absolu, neuf et privé, choisi par le principal. `build-final.sh` utilise packageRoot/source. Le principal doit préparer cette copie Git depuis le commit fusionné propre, avec un original inchangé séparé pour la comparaison. Il ne doit copier aucun node_modules existant.

Les seules adaptations du build sont argv1 validé absolu, /tmp/b149.XXXXXX, version0.0.45-local.149 et PATH Node24 depuis /Users/moi/.cache/t3-toolchains/148/node-v24.13.1-darwin-arm64/bin. Le trap, l'environnement public, frozen install, rebuild récursif, mise à jour des versions, build et package sont conservés. Aucun filtre d'exclusion ajouté.

La signature conserve le parcours Mach-O, les entitlements existants et la vérification stricte. Avant son appel, packageRoot/native-stage.txt doit désigner uniquement l'application de staging privée choisie par le principal, jamais une application installée. packageRoot/entitlements doit être absent ; le script refuse de le recréer.

verify-final.mjs et sqlite-smoke.cjs sont identiques octet pour octet aux originaux. Pour verify-final, fournir tous les chemins absolus et explicitement --zip : sa valeur par défaut pointe au dossier des outils, différent du packageRoot. Ce contrôle148 ne prouve pas à lui seul les fonctionnalités149 : les recettes149 restent les preuves séparées. Le smoke reçoit déjà son chemin SQLite par argv2 ; les noms SQL smoke148/isolated148 sont des données héritées, pas des chemins ni une version de livraison. Il doit être appelé sous l'Electron du staging avec une base privée neuve.

## Routine Bridget proposée, non exécutée

1. Reprendre les gates de /Users/moi/.cache/bridget-cleanup149-build148-proofs/bridget-final148.wDyecn/run-build148.py : clone Git privé propre, HEAD complet attendu communiqué par le principal, git-common-dir propre au clone et unique worktree ; manifeste de tous les fichiers suivis et SHA256 Cargo.lock avant/après ; aucun changement même non suivi. Ne jamais réutiliser le hash148 codé dans cette archive.
2. Réutiliser /Volumes/8TB2/50-repos-archives/validation-cache/bridget149-target, après libération exclusive des compilateurs. Conserver /Users/moi/.cargo et ses dépendances installées. Pas de copie du registre Git/Cargo, pas de suppression ni cargo clean.
3. Retirer BRIDGET_BUILD_ID, BRIDGET_T3_* et T3CODE_* de l'environnement de build. Fixer CARGO_TARGET_DIR au cache149 ci-dessus, CARGO_HOME=/Users/moi/.cargo, CARGO_NET_OFFLINE=true, CARGO_BUILD_JOBS=2 et CARGO_INCREMENTAL=0. TMPDIR doit être un dossier privé canonique neuf sous /tmp/b149.*.
4. Dans le clone Bridget propre, commande prévue : cargo build --locked --offline --release -p bridget-daemon --bin bridget --message-format=json. Le principal doit conserver les messages JSON et stderr dans ses logs privés. Cette commande Cargo directe évite l'entretien automatique de scripts/build.py : ce wrapper peut purger des caches et retirer des worktrees fusionnés après succès. Aucun changement du wrapper source n'est proposé.
5. build.rs lit CARGO_MANIFEST_DIR à l'exécution. build_identity.rs calcule le vrai HEAD court12 et ajoute dirty si les fichiers suivis changent. Ne fournir aucun override de BRIDGET_BUILD_ID. Avec le cache partagé, ne pas reprendre l'assertion148 « un seul dossier build/bridget-daemon-*/output » : sélectionner les messages build-script-executed et compiler-artifact du package bridget-daemon de ce build, leur out_dir/executable, puis contrôler l'identité HEAD attendue et les octets du binaire. Ne pas choisir le premier ancien output trouvé.
6. Copier le binaire produit dans un dossier privé de livraison avant toute signature. Conserver SHA256 non signé, signer cette copie ad hoc, vérifier strictement et contrôler --version ; relier commit, identité embarquée, chemin d'artefact, SHA signé/non signé, toolchains et logs dans un reçu. Cela préserve les binaires immuablesr8 et le cache partagé. Aucun remplacement installé ni restart ne fait partie de cette routine.

Faisabilité : aucun node_modules ni cache source partagé copié. L'installation privée T3 sera faite seulement par le principal. Les estimations transmises de8,5Go pour l'installation et52Go disponibles ne sont pas une mesure fraîche ; capacité, gates des sources propres, dépendances offline et fonctionnalités149 restent à contrôler avant exécution.
