"""Signature privée : objets Mach-O, conteneurs imbriqués, puis application."""
import json
import plistlib
import subprocess
import sys
from pathlib import Path

if len(sys.argv) != 2 or not Path(sys.argv[1]).is_absolute():
    raise SystemExit("Usage: sign-stage.py /absolute/new-package-root")
root = Path(sys.argv[1])
app = Path((root / 'native-stage.txt').read_text().strip())
entitlements_root = root / 'entitlements'
entitlements_root.mkdir(mode=0o700, exist_ok=False)
magic = {bytes.fromhex(value) for value in (
    'feedface', 'cefaedfe', 'feedfacf', 'cffaedfe',
    'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca',
)}
machos = []
containers = []
for path in app.rglob('*'):
    if path.is_symlink():
        continue
    if path.is_dir():
        if path.suffix in ('.app', '.framework', '.xpc', '.appex', '.bundle'):
            containers.append(path)
    elif path.is_file():
        with path.open('rb') as stream:
            first = stream.read(4)
        if first in magic:
            kind = subprocess.check_output(['/usr/bin/file', '-b', str(path)], text=True)
            if 'Mach-O' in kind:
                machos.append(path)
objects = sorted(machos, key=lambda p: (-len(p.parts), str(p)))
objects += sorted(containers, key=lambda p: (-len(p.parts), str(p)))
objects += [app]
records = []
for index, path in enumerate(objects):
    observed = subprocess.run(['/usr/bin/codesign', '-d', '--entitlements', ':-', str(path)], capture_output=True)
    signed = observed.returncode == 0
    entitlements = plistlib.loads(observed.stdout) if observed.stdout.strip() else {}
    xml = entitlements_root / f'{index:03d}.plist'
    xml.write_bytes(plistlib.dumps(entitlements))
    records.append({'path': str(path), 'wasSigned': signed, 'entitlements': entitlements, 'snapshot': str(xml)})
(root / 'signing-before.json').write_text(json.dumps(records, indent=2) + '\n')
with (root / 'sign-stage.log').open('w') as log:
    for record in records:
        args = ['/usr/bin/codesign', '--force', '--sign', '-']
        if record['wasSigned']:
            args += ['--preserve-metadata=entitlements,flags,runtime']
        # Only pre-existing entitlement values can be carried into the signature.
        if record['entitlements']:
            args += ['--entitlements', record['snapshot']]
        args += [record['path']]
        log.write('Signing ' + record['path'] + '\n')
        log.flush()
        subprocess.run(args, stdout=log, stderr=log, check=True)
    for record in records:
        observed = subprocess.run(['/usr/bin/codesign', '-d', '--entitlements', ':-', record['path']], capture_output=True, check=True)
        actual = plistlib.loads(observed.stdout) if observed.stdout.strip() else {}
        if actual != record['entitlements']:
            raise RuntimeError('Entitlements changed during private signing')
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', '--deep', str(app)], stdout=log, stderr=log, check=True)
(root / 'signing-receipt.json').write_text(json.dumps({
    'nativeStage': str(app), 'machObjects': len(machos), 'nestedContainers': len(containers),
    'objectsSigned': len(records), 'entitlementsPreservedExactly': True,
    'identity': 'ad hoc', 'strictDeepVerifyRc': 0,
    'installed': False, 'restarted': False,
}, indent=2) + '\n')
print(json.dumps({'objectsSigned': len(records), 'strictDeepVerifyRc': 0, 'entitlementsPreservedExactly': True}))
