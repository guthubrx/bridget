#!/bin/bash
set -euo pipefail
umask 077
if [ "$#" -ne 1 ] || [[ "$1" != /* ]]; then
    printf 'Usage: build-final.sh /absolute/new-package-root\n' >&2
    exit 2
fi
package_root="$1"
source_root="$package_root/source"
cd "$source_root"
validation_tmp=$(mktemp -d /tmp/b149.XXXXXX)
validation_tmp=$(cd "$validation_tmp" && pwd -P)
printf '%s\n' "$validation_tmp" > "$package_root/build-tmpdir.txt"
export TMPDIR="$validation_tmp"
export PATH="/Users/moi/.cache/t3-toolchains/148/node-v24.13.1-darwin-arm64/bin:$source_root/node_modules/.bin:/Users/moi/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
test "$(node --version)" = v24.13.1
export APP_VERSION=0.0.45-local.149
unset T3CODE_DESKTOP_DEV VITE_HTTP_URL VITE_WS_URL
export T3CODE_DESKTOP_SIGNED=false
export T3CODE_RELAY_URL=https://relay.t3.codes
export T3CODE_CLERK_PUBLISHABLE_KEY=pk_live_Y2xlcmsudDMuY29kZXMk
export T3CODE_CLERK_JWT_TEMPLATE=t3-relay
export T3CODE_CLERK_CLI_OAUTH_CLIENT_ID=hzxSgY2cH10sDU2r
phase=dependencies
trap 'rc=$?; printf "phase=%s rc=%s\n" "$phase" "$rc" > "$package_root/build-exit.txt"' EXIT
printf 'Phase: dependencies\n'
pnpm install --frozen-lockfile > "$package_root/install-dependencies.log" 2>&1
phase=rebuild-dependencies
printf 'Phase: rebuild-dependencies\n'
pnpm rebuild --recursive > "$package_root/rebuild-dependencies.log" 2>&1
phase=version
printf 'Phase: version\n'
node scripts/update-release-package-versions.ts "$APP_VERSION" --root "$source_root" > "$package_root/version.log" 2>&1
phase=desktop
printf 'Phase: desktop\n'
pnpm run build:desktop > "$package_root/build-desktop.log" 2>&1
phase=package
printf 'Phase: package\n'
node scripts/build-desktop-artifact.ts --platform mac --target zip --arch arm64 --build-version "$APP_VERSION" --output-dir "$package_root/artifacts" --skip-build --keep-stage --verbose > "$package_root/packaging.log" 2>&1
phase=complete
printf 'Build complete\n'
