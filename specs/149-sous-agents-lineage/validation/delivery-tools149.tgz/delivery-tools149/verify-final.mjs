#!/usr/bin/env node
// Lecture seule. Les outils Git ci-dessous ne sont exécutés qu'à l'appel explicite.
import * as Fs from "node:fs";
import * as Crypto from "node:crypto";
import * as Module from "node:module";
import * as Path from "node:path";
import * as ChildProcess from "node:child_process";
import { parseArgs, isDeepStrictEqual } from "node:util";
import { fileURLToPath } from "node:url";

const cacheRoot = Path.dirname(fileURLToPath(import.meta.url));
const { values } = parseArgs({ options: {
  commit: { type: "string" }, version: { type: "string" },
  stage: { type: "string" }, original: { type: "string" }, source: { type: "string" },
  app: { type: "string" }, zip: { type: "string" }, help: { type: "boolean" },
} });
if (values.help) {
  console.log("Usage: node verify-final.mjs --commit <40 hex> --version <version> --stage </absolute/native.app> --original </absolute/clean-source> --source </absolute/build-source> [--app </absolute/copy.app>] [--zip </absolute/package.zip>]\nRead-only verification; signature verification is a separate codesign command.");
  process.exit(0);
}
for (const name of ["commit", "version", "stage", "original", "source"]) {
  if (!values[name]) throw new Error(`Missing --${name}`);
}
if (!/^[a-f0-9]{40}$/i.test(values.commit)) throw new Error("--commit must be a full 40-character hash");
if (!/^[A-Za-z0-9][A-Za-z0-9.+-]*$/.test(values.version)) throw new Error("Invalid version");
const commit = values.commit.toLowerCase();
const version = values.version;
const source = values.source;
const original = values.original;
const stage = values.stage;
const app = values.app ?? stage;
const zip = values.zip ?? Path.join(cacheRoot, "artifacts", `T3-Code-${version}-arm64.zip`);
for (const location of [source, original, stage, app, zip]) {
  if (!Path.isAbsolute(location)) throw new Error("All filesystem arguments must be absolute");
}
if (Fs.realpathSync(source) === Fs.realpathSync(original)) {
  throw new Error("Build source and unchanged original must be separate directories");
}
const checks = [];
const hashes = {};
const verify = (name, pass) => {
  checks.push({ name, pass: Boolean(pass) });
  if (!pass) process.exitCode = 1;
};
const run = (command, args) => ChildProcess.execFileSync(command, args, {
  encoding: "utf8", timeout: 15000, maxBuffer: 32 * 1024 * 1024,
});
const git = (directory, ...args) => run("git", ["-C", directory, ...args]);
const sha = (bytes) => Crypto.createHash("sha256").update(bytes).digest("hex");
async function hashFile(location) {
  const hash = Crypto.createHash("sha256");
  for await (const bytes of Fs.createReadStream(location)) hash.update(bytes);
  return hash.digest("hex");
}
function inventory(directory, prefix = "") {
  return Fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const relative = Path.posix.join(prefix, entry.name);
    return entry.isDirectory()
      ? inventory(Path.join(directory, entry.name), relative)
      : [relative];
  }).sort();
}
function sameFile(actual, expected) {
  if (!Fs.existsSync(actual) || !Fs.existsSync(expected)) return false;
  const a = Fs.lstatSync(actual), b = Fs.lstatSync(expected);
  if (a.isSymbolicLink() || b.isSymbolicLink()) {
    return a.isSymbolicLink() && b.isSymbolicLink()
      && Fs.readlinkSync(actual) === Fs.readlinkSync(expected);
  }
  return a.isFile() && b.isFile() && a.size === b.size && (a.mode & 0o111) === (b.mode & 0o111)
    && Fs.readFileSync(actual).equals(Fs.readFileSync(expected));
}
const releaseManifests = new Set([
  "apps/server/package.json", "apps/desktop/package.json",
  "apps/web/package.json", "packages/contracts/package.json",
]);

try {
  verify("private build clone at final commit", git(source, "rev-parse", "HEAD").trim() === commit);
  verify("original at final commit", git(original, "rev-parse", "HEAD").trim() === commit);
  verify("original tracked files unchanged", git(original, "status", "--porcelain=v1", "--untracked-files=no").trim() === "");
  const tracked = git(source, "ls-files", "-z").split("\0").filter(Boolean);
  const originalTracked = git(original, "ls-files", "-z").split("\0").filter(Boolean);
  verify("same tracked source inventory", isDeepStrictEqual([...tracked].sort(), [...originalTracked].sort()));
  const indexRecords = (directory) => new Map(git(directory, "ls-files", "--stage", "-z")
    .split("\0").filter(Boolean).map((record) => {
      const tab = record.indexOf("\t");
      const [mode, objectId, stageNumber] = record.slice(0, tab).split(" ");
      return [record.slice(tab + 1), { mode, objectId, stageNumber }];
    }));
  const sourceIndex = indexRecords(source), originalIndex = indexRecords(original);
  verify("tracked source modes identical and indexes unmerged", tracked.every((file) => {
    const a = sourceIndex.get(file), b = originalIndex.get(file);
    return a?.mode === b?.mode && a?.stageNumber === "0" && b?.stageNumber === "0";
  }));
  const gitLinks = tracked.filter((file) => sourceIndex.get(file)?.mode === "160000");
  for (const file of gitLinks) verify(`gitlink commit pointer exact: ${file}`,
    originalIndex.get(file)?.mode === "160000"
      && sourceIndex.get(file).objectId === originalIndex.get(file).objectId);
  const gitLinkSet = new Set(gitLinks);
  const sourceFiles = tracked.filter((file) => !gitLinkSet.has(file));
  const sourceChanges = sourceFiles.filter((file) => !sameFile(Path.join(source, file), Path.join(original, file)));
  verify("only four release manifests changed", sourceChanges.length === 4 && sourceChanges.every((file) => releaseManifests.has(file)));
  for (const file of releaseManifests) {
    const actual = JSON.parse(Fs.readFileSync(Path.join(source, file), "utf8"));
    const expected = JSON.parse(Fs.readFileSync(Path.join(original, file), "utf8"));
    verify(`release manifest version: ${file}`, actual.version === version);
    verify(`release manifest changes version only: ${file}`, isDeepStrictEqual({ ...actual, version: expected.version }, expected));
  }

  const archive = Path.join(app, "Contents/Resources/app.asar");
  const asar = Module.createRequire(Path.join(source, "scripts/package.json"))("@electron/asar");
  const packed = (file) => asar.extractFile(archive, file);
  const metadata = JSON.parse(packed("package.json").toString());
  verify("package version and build version", metadata.version === version && metadata.buildVersion === version);
  verify("embedded final commit", metadata.t3codeCommitHash === commit.slice(0, 12));
  verify("desktop boot entry", metadata.main === "apps/desktop/dist-electron/boot.cjs");
  const plist = (key) => run("/usr/libexec/PlistBuddy", ["-c", `Print :${key}`, Path.join(app, "Contents/Info.plist")]).trim();
  verify("stable bundle identity", plist("CFBundleIdentifier") === "com.t3tools.t3code"
    && plist("CFBundleExecutable") === "T3 Code (Alpha)" && plist("CFBundleName") === "T3 Code (Alpha)");
  verify("plist version", plist("CFBundleShortVersionString") === version && plist("CFBundleVersion") === version);
  hashes.asar = await hashFile(archive);
  hashes.zip = await hashFile(zip);
  const entries = asar.listPackage(archive).map((entry) => entry.replace(/^\//, ""));
  let webFiles = 0, freshOutputFiles = 0, unpackedFiles = 0;
  const serverChunks = [], clientChunks = [];
  for (const entry of entries) {
    if (entry.split("/").includes("..") || Path.isAbsolute(entry)) throw new Error("Unsafe archive entry");
    const stat = asar.statFile(archive, entry);
    if (stat.files) continue;
    if (stat.unpacked) {
      unpackedFiles += 1;
      verify(`native unpacked file exists: ${entry}`, Fs.existsSync(`${archive}.unpacked/${entry}`));
    }
    if (!entry.startsWith("apps/server/dist/") && !entry.startsWith("apps/desktop/dist-electron/")) continue;
    const bytes = packed(entry);
    verify(`fresh output exact: ${entry}`, Fs.existsSync(Path.join(source, entry))
      && bytes.equals(Fs.readFileSync(Path.join(source, entry))));
    hashes[entry] = sha(bytes);
    freshOutputFiles += 1;
    if (entry.startsWith("apps/server/dist/client/")) {
      webFiles += 1;
      if (/\.(?:js|html)$/.test(entry)) clientChunks.push(bytes.toString());
    } else if (entry.startsWith("apps/server/dist/") && /\.(?:mjs|cjs|js)$/.test(entry)) {
      serverChunks.push(bytes.toString());
    }
  }
  const server = serverChunks.join("\n");
  const client = clientChunks.join("\n");
  verify("compiled server chunks present", serverChunks.length > 0);
  verify("compiled client files present", clientChunks.length > 0 && webFiles > 0);
  verify("private MCP session introspection embedded", server.includes("bridget_session"));
  verify("per-session Bridget endpoint injection embedded", server.includes("BRIDGET_T3_MCP_ENDPOINT"));
  verify("human watch RPC and native CLI embedded", server.includes("bridget.watch")
    && /["']thread["']\s*,\s*["']watch["']\s*,\s*["']--t3-thread["']/.test(server));
  verify("recent reader and unavailable binding embedded", server.includes("history_recent") && server.includes("binding_unavailable"));
  verify("Bridget panel and snapshot reader embedded", client.includes("Bridget") && client.includes("history_recent") && client.includes("snapshot_seq"));
  for (const [name, value] of Object.entries({
    relay: "https://relay.t3.codes", publishableKey: "pk_live_Y2xlcmsudDMuY29kZXMk",
    oauthClientId: "hzxSgY2cH10sDU2r", jwtTemplate: "t3-relay",
  })) verify(`public production config retained: ${name}`, server.includes(value));

  const appFiles = inventory(app), stageFiles = inventory(stage);
  verify("complete native app inventory equals stage", isDeepStrictEqual(appFiles, stageFiles));
  for (const file of appFiles) verify(`native package exact versus stage: ${file}`, sameFile(Path.join(app, file), Path.join(stage, file)));
  // Compare the ZIP itself with the app without extracting or writing any file.
  const zipComparison = JSON.parse(run("python3", ["-c", String.raw`
import hashlib, json, pathlib, stat, sys, zipfile
app = pathlib.Path(sys.argv[2])
with zipfile.ZipFile(sys.argv[1]) as archive:
    records = archive.infolist()
    roots = {r.filename.split('/')[0] for r in records if r.filename.split('/')[0].endswith('.app')}
    if len(roots) != 1:
        raise ValueError('Expected one application root')
    root = next(iter(roots)) + '/'
    entries, mismatches = [], []
    for record in records:
        if not record.filename.startswith(root) or record.is_dir():
            continue
        relative = record.filename[len(root):]
        components = pathlib.PurePosixPath(relative)
        if components.is_absolute() or '..' in components.parts:
            raise ValueError('Unsafe package path')
        entries.append(relative)
        actual = app.joinpath(*components.parts)
        contents = archive.read(record)
        mode = record.external_attr >> 16
        if stat.S_ISLNK(mode):
            ok = actual.is_symlink() and actual.readlink().as_posix() == contents.decode('utf8')
        else:
            ok = actual.is_file() and not actual.is_symlink() and hashlib.sha256(actual.read_bytes()).digest() == hashlib.sha256(contents).digest()
        if not ok:
            mismatches.append(relative)
    print(json.dumps({'entries': sorted(entries), 'duplicates': len(entries) != len(set(entries)), 'mismatches': mismatches}))
`, zip, app]));
  verify("ZIP native app file inventory exact", !zipComparison.duplicates && isDeepStrictEqual(appFiles, zipComparison.entries));
  verify("ZIP native app bytes and links exact", zipComparison.mismatches.length === 0);
  verify("native unpacked payload present", unpackedFiles > 0);
  console.log(JSON.stringify({ application: app, nativeStage: stage, source, original, zip,
    sourceCommit: commit, version, commitEmbedded: metadata.t3codeCommitHash,
    hashes, serverChunks: serverChunks.length, clientChunks: clientChunks.length,
    webFiles, freshOutputFiles, unpackedFiles, completeAppFiles: appFiles.length,
    zipAppFilesCompared: zipComparison.entries.length,
    sourcesCompared: sourceFiles.length, gitlinkCommitPointersCompared: gitLinks.length,
    gitlinkPaths: gitLinks, privateSourceChanges: sourceChanges,
    independentAppCopyCompared: Fs.realpathSync(app) !== Fs.realpathSync(stage),
    checks, passed: checks.filter((check) => check.pass).length,
    failed: checks.filter((check) => !check.pass).length,
    signatureVerification: "separate codesign --verify --strict --deep command required",
    installed: false, restarted: false,
  }, null, 2));
} catch {
  // Ne pas publier de données de fichier, d'environnement ou de sortie de sous-processus.
  verify("verification completed without missing input or execution failure", false);
  console.log(JSON.stringify({ sourceCommit: commit, version, checks,
    passed: checks.filter((check) => check.pass).length,
    failed: checks.filter((check) => !check.pass).length,
    error: "Verification could not complete; verify input paths, dependencies and read access.",
    installed: false, restarted: false,
  }, null, 2));
}
